﻿namespace PetStore.ConsoleClient
{
    using System;
    using PetStore.Importer;

    public class Startup
    {        
        // Entities should be imported in the order below (Did not have time to implement Builder pattern).
        // Geneating 5K pets and 20K products could take a while depending on your machine.
        // It works with no problems though, just update the constant in ProductsImporter from 2000 to 20000 and in PetsImporter from 500 to 5K.
        
        public static void Main()
        {
            var countries = new CountriesImporter();
            var species = new SpeciesImporter();
            var pets = new PetsImporter();
            var categories = new CategoriesImporter();
            var products = new ProductsImporter();

            countries.Import();
            species.Import();
            pets.Import();
            categories.Import();
            products.Import();
        }
    }
}
