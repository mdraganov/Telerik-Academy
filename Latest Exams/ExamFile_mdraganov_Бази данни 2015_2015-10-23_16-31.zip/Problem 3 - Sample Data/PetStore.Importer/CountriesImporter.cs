﻿namespace PetStore.Importer
{
    using System;
    using PetStore.Data;

    public class CountriesImporter : IImporter
    {
        private const int NumberOfRandomCountriesGenerated = 20;

        public void Import()
        {
            Console.Write("\nGenerating Countries: ");

            var db = new PetStoreEntities();

            for (int i = 0; i < NumberOfRandomCountriesGenerated; i++)
            {
                db.Countries.Add(new Country { Name = RandomGenerator.GetString(5, 50) });

                Console.Write(".");
            }

            db.SaveChanges();
            db.Dispose();
        }
    }
}
