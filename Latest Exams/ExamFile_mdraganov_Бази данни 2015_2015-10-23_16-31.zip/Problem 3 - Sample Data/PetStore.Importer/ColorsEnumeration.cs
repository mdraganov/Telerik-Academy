﻿namespace PetStore.Importer
{
    public enum ColorsEnumeration
    {
        black = 0,
        white = 1,
        red = 2,
        mixed = 3
    }
}
