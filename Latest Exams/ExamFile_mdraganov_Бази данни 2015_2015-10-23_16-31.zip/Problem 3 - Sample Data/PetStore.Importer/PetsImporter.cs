﻿namespace PetStore.Importer
{
    using System;
    using System.Linq;
    using PetStore.Data;

    public class PetsImporter : IImporter
    {
        private const int NumberOfRandomPetsGenerated = 500; // 5000

        public void Import()
        {
            Console.Write("\nGenerating Pets: ");

            var db = new PetStoreEntities();
            var species = db.Species.ToList();
            Species currentSpecies = species[RandomGenerator.GetNumber(0, species.Count - 1)];
            int numberOfPetsForCurrentSpecies = RandomGenerator.GetNumber(40, 60);
            int counter = 0;

            for (int i = 0; i < NumberOfRandomPetsGenerated; i++)
            {
                string breed = RandomGenerator.GetString(5, 30);
                DateTime birthdate = RandomGenerator.GetDate(new DateTime(2010, 1, 1), DateTime.Now.AddDays(-60));
                decimal price = RandomGenerator.GetNumber(5, 2500);
                Color color = new Color { Name = ((ColorsEnumeration)RandomGenerator.GetNumber(0, 3)).ToString() };

                db.Pets.Add(new Pet
                {
                    Species = currentSpecies,
                    Birthdate = birthdate,
                    Color = color,
                    Price = price,
                    Breed = breed
                });

                counter++;

                if (counter == numberOfPetsForCurrentSpecies)
                {
                    currentSpecies = species[RandomGenerator.GetNumber(0, species.Count - 1)];
                    numberOfPetsForCurrentSpecies = RandomGenerator.GetNumber(40, 60);
                    counter = 0;
                }

                Console.Write(".");
            }

            db.SaveChanges();
            db.Dispose();
        }
    }
}
