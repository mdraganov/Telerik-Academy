﻿namespace PetStore.Importer
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using PetStore.Data;

    public class ProductsImporter : IImporter
    {
        private const int NumberOfRandomPetsGenerated = 2000; // 20000

        public void Import()
        {
            Console.Write("\nGenerating Products: ");

            var db = new PetStoreEntities();
            var categories = db.Categories.ToList();
            var species = db.Species.ToList();
            Category currentCategory = categories[RandomGenerator.GetNumber(0, categories.Count - 1)];
            int numberOfProductsForCurrentCategory = RandomGenerator.GetNumber(300, 500);
            int categoryCounter = 0;

            for (int i = 0; i < NumberOfRandomPetsGenerated; i++)
            {
                string name = RandomGenerator.GetString(5, 25);
                decimal price = RandomGenerator.GetNumber(10, 1000);
                ICollection<Species> suitableSpecies = new HashSet<Species>();
                int suitableSpeciesCount = RandomGenerator.GetNumber(2, 10);
                for (int j = 0; j < suitableSpeciesCount; j++)
                {
                    suitableSpecies.Add(species[RandomGenerator.GetNumber(0, species.Count - 1)]);
                }

                db.PetProducts.Add(new PetProduct
                {
                    Name = name,
                    Price = price,
                    Category = currentCategory,
                    Species = suitableSpecies
                });

                categoryCounter++;

                if (categoryCounter == numberOfProductsForCurrentCategory)
                {
                    currentCategory = categories[RandomGenerator.GetNumber(0, categories.Count - 1)];
                    numberOfProductsForCurrentCategory = RandomGenerator.GetNumber(300, 500);
                    categoryCounter = 0;
                }

                Console.Write(".");
            }

            db.SaveChanges();
            db.Dispose();
        }
    }
}
