﻿namespace PetStore.Importer
{
    public interface IImporter
    {
        void Import();
    }
}
