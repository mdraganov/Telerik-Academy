﻿namespace PetStore.Importer
{
    using System;
    using PetStore.Data;

    public class CategoriesImporter : IImporter
    {
        private const int NumberOfRandomCategoriesGenerated = 50;

        public void Import()
        {
            Console.Write("\nGenerating Categories: ");

            var db = new PetStoreEntities();

            for (int i = 0; i < NumberOfRandomCategoriesGenerated; i++)
            {
                db.Categories.Add(new Category { Name = RandomGenerator.GetString(5, 20) });
                Console.Write(".");
            }

            db.SaveChanges();
            db.Dispose();
        }
    }
}