﻿namespace PetStore.Importer
{
    using System;
    using System.Text;

    internal static class RandomGenerator
    {
        private const string Chars = "ABCDEFGHIJKLMNOPQRSTUWXYZabcdefghijklmnopqrstuwxyz0123456789";
        private static Random random = new Random();

        internal static int GetNumber(int min = 0, int max = 1000)
        {
            return random.Next(min, max + 1);
        }

        internal static string GetString(int minLength = 0, int maxLength = 1000)
        {
            var length = GetNumber(minLength, maxLength);
            var result = new StringBuilder();

            for (int i = 0; i < length; i++)
            {
                result.Append(Chars[GetNumber(0, Chars.Length - 1)]);
            }
             
            return result.ToString();
        }

        internal static DateTime GetDate(DateTime? start = null, DateTime? end = null)
        {
            int year = GetNumber(start.Value.Year, end.Value.Year);
            int month = GetNumber(start.Value.Month, end.Value.Month);
            int day = GetNumber(start.Value.Day, end.Value.Day);

            return new DateTime(year, month, day);
        }
    }
}
