﻿namespace PetStore.Importer
{
    using System;
    using System.Linq;
    using PetStore.Data;

    public class SpeciesImporter : IImporter
    {
        private const int NumberOfRandomSpeciesGenerated = 100;

        public void Import()
        {
            Console.Write("\nGenerating Species: ");
            var db = new PetStoreEntities();
            var countries = db.Countries.ToList();
            Country currentCountry = countries[RandomGenerator.GetNumber(0, countries.Count - 1)];
            int numberOfSpeciesForCurrentCountry = RandomGenerator.GetNumber(1, 9);
            int counter = 0;

            for (int i = 0; i < NumberOfRandomSpeciesGenerated; i++)
            {
                string speciesName = RandomGenerator.GetString(5, 50);
                db.Species.Add(new Species { Name = speciesName, Country = currentCountry });
                counter++;

                if (counter == numberOfSpeciesForCurrentCountry)
                {
                    currentCountry = countries[RandomGenerator.GetNumber(0, countries.Count - 1)];
                    numberOfSpeciesForCurrentCountry = RandomGenerator.GetNumber(1, 9);
                    counter = 0;
                }

                Console.Write(".");
            }

            db.SaveChanges();
            db.Dispose();
        }
    }
}
