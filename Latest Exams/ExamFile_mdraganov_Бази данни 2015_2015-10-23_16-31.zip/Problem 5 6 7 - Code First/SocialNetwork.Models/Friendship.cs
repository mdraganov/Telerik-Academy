﻿namespace SocialNetwork.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class Friendship
    {
        private ICollection<ChatMessage> chatMessages;

        public Friendship()
        {
            this.chatMessages = new HashSet<ChatMessage>();
        }

        public int FriendshipId { get; set; }

        [Required]
        [Index]
        public bool IsApproved { get; set; }

        [Required]
        public DateTime DateOfApproval { get; set; }
                
        public int FirstUserId { get; set; }

        public int SecondUserId { get; set; }
                
        public virtual User FirstUser { get; set; }
        
        public virtual User SecondUser { get; set; }

        public virtual ICollection<ChatMessage> ChatMessage
        {
            get { return this.chatMessages; }
            set { this.chatMessages = value; }
        }
    }
}
