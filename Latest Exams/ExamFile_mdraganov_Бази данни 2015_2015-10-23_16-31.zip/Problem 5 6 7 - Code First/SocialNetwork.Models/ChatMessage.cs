﻿namespace SocialNetwork.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class ChatMessage
    {
        public int ChatMessageId { get; set; }

        public int FriendshipId { get; set; }

        public virtual Friendship Friendship { get; set; }

        [Required]
        public string Content { get; set; }

        [Index]
        public DateTime Sent { get; set; }

        public DateTime Read { get; set; }

        [Column("Author")]
        public int UserId { get; set; }

        public virtual User User { get; set; }

    }
}
