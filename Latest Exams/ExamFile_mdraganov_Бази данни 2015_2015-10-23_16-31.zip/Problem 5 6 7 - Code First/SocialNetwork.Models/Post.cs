﻿namespace SocialNetwork.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.ComponentModel.DataAnnotations;

    public class Post
    {
        private ICollection<User> users;

        public Post()
        {
            this.users = new HashSet<User>();
        }

        public int PostId { get; set; }

        [Required]
        [MinLength(10)]
        public string Content { get; set; }

        [Required]
        public DateTime PostingDate { get; set; }

        public ICollection<User> Users
        {
            get { return this.users; }
            set { this.users = value; }
        }
    }
}
