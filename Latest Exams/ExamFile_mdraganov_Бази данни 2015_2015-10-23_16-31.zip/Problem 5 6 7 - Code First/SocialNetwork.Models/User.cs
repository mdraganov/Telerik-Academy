﻿namespace SocialNetwork.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class User
    {
        private ICollection<Image> images;
        private ICollection<ChatMessage> chatMessages;
        private ICollection<Post> posts;
        private ICollection<Friendship> firstUserFriendships;
        private ICollection<Friendship> secondUserFriendships;

        public User()
        {
            this.images = new HashSet<Image>();
            this.chatMessages = new HashSet<ChatMessage>();
            this.posts = new HashSet<Post>();
            this.firstUserFriendships = new HashSet<Friendship>();
            this.secondUserFriendships = new HashSet<Friendship>();
        }

        public int UserId { get; set; }

        [Required]
        [MinLength(4)]
        [MaxLength(20)]
        [Index(IsUnique = true)]
        public string UserName { get; set; }

        [MinLength(2)]
        [MaxLength(50)]
        public string FirstName { get; set; }

        [MinLength(2)]
        [MaxLength(50)]
        public string LastName { get; set; }

        [Required]
        public DateTime RegistrationDate { get; set; }

        public virtual ICollection<Image> Images
        {
            get { return this.images; }
            set { this.images = value; }
        }

        public virtual ICollection<ChatMessage> ChatMessage
        {
            get { return this.chatMessages; }
            set { this.chatMessages = value; }
        }

        public virtual ICollection<Post> Posts
        { 
            get { return this.posts; }
            set { this.posts = value; }
        }

        public virtual ICollection<Friendship> FirstUserFriendships
        {
            get { return this.firstUserFriendships; }
            set { this.firstUserFriendships = value; }
        }

        public virtual ICollection<Friendship> SecondUserFriendships
        {
            get { return this.secondUserFriendships; }
            set { this.secondUserFriendships = value; }
        }
    }
}
