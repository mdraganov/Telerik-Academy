﻿namespace SocialNetwork.ConsoleClient
{
    using System.Linq;
    using System.Data.Entity;
    using SocialNetwork.Data;
    using SocialNetwork.Data.Migrations;
    using SocialNetwork.Models;

    public class Startup
    {
        public static void Main()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<SocialNetworkDBContext, Configuration>());

            var db = new SocialNetworkDBContext();

            db.Users.Count();
        }
    }
}
