﻿namespace SocialNetwork.Data
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Data.Entity;
    using SocialNetwork.Models;

    public class SocialNetworkDBContext : DbContext
    {
        public SocialNetworkDBContext()
            : base("SocialNetworkDB")
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Friendship>()
                        .HasRequired(f => f.FirstUser)
                        .WithMany(u => u.FirstUserFriendships)
                        .HasForeignKey(f => f.FirstUserId)
                        .WillCascadeOnDelete(false);

            modelBuilder.Entity<Friendship>()
                        .HasRequired(f => f.SecondUser)
                        .WithMany(u => u.SecondUserFriendships)
                        .HasForeignKey(f => f.SecondUserId)
                        .WillCascadeOnDelete(false);
        }

        public virtual DbSet<User> Users { get; set; }

        public virtual DbSet<Post> Posts { get; set; }

        public virtual DbSet<Image> Images { get; set; }

        public virtual DbSet<Friendship> Friendships { get; set; }

        public virtual DbSet<ChatMessage> ChatMessages { get; set; }
    }
}
